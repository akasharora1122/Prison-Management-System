//
//  tableViewController.h
//  PM
//
//  Created by Techwin Labs on 28/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

//#import "CriminalRecordViewController.h"

@interface tableViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSArray *tableData;
}

@property (nonatomic, retain) IBOutlet UITableView  *m_TableView;

@end
