//
//  SignupViewController.m
//  PM
//
//  Created by Techwin Labs on 03/06/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "SignupViewController.h"

@interface SignupViewController ()

@end

@implementation SignupViewController
@synthesize m_PassTextfield, m_EmailTextfield,m_RepeatPassTextfield, m_SignupButton;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = NO;
}


- (IBAction)signupPressed:(id)sender {

    if ([m_PassTextfield.text isEqualToString:m_RepeatPassTextfield.text] && [m_PassTextfield.text length]>4) {
    
        if ([m_EmailTextfield.text length]>0) {
            
            PFQuery *query = [PFQuery queryWithClassName:@"Login"];
            [query whereKey:@"Email" equalTo:m_EmailTextfield.text];
            [query whereKey:@"Password" equalTo:m_PassTextfield.text];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
                if (!err) {
                    
                    if ([array count] > 0) {
                        
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Error, entry already exist!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [alert show];
                        
                    } else {
                        
                        //Save
                            PFObject *testObject = [PFObject objectWithClassName:@"Login"];
                            testObject[@"Email"] = m_EmailTextfield.text;
                            testObject[@"Password"] = m_PassTextfield.text;
                            [testObject saveInBackground];

                        
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Jailor Added Successfully!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [alert show];
                        [self.navigationController popToRootViewControllerAnimated:YES];
                    }
                }
                else {
                    NSLog(@"Fail");
                    
                }
            }];

            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Invalid Email!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
        }
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Password Mismatch!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
