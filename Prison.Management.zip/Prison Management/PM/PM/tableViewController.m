//
//  tableViewController.m
//  PM
//
//  Created by Techwin Labs on 28/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "tableViewController.h"

@interface tableViewController ()

@end

@implementation tableViewController
//@synthesize m_TableView;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    tableData = [[NSArray alloc] initWithObjects:@"Robery", @"Murder", @"Rape",@"Assault",@"Kidnapping",@"Homicide",@"Forgery",@"Cyber Crime",@"Burglary",nil];
            }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    [self.navigationController popViewControllerAnimated:YES];
// Dispose of any resources that can be recreated.
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = NO;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [tableData count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *TableIdentifier = @"TableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TableIdentifier];
    }
    
    for (UIView *view in cell.contentView.subviews) {
        [view removeFromSuperview];
    }
    
    UILabel *separaterLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 44, 320, 2)];
    [separaterLabel setBackgroundColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:separaterLabel];

    
    cell.textLabel.text = [tableData objectAtIndex:indexPath.row];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%@",[tableData objectAtIndex:indexPath.row]);
    
    [[NSUserDefaults standardUserDefaults] setObject:[tableData objectAtIndex:indexPath.row] forKey:@"Crime"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self.navigationController popViewControllerAnimated:YES];
}





-(IBAction)onclickhome:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
