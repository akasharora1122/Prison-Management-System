//
//  AddParoleViewController.h
//  PM
//
//  Created by Techwin Labs on 04/08/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface AddParoleViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray* m_Array;
    
}

@property (strong, nonatomic) IBOutlet UITableView *m_othertableview;
@property (assign, nonatomic) int             m_ConvictSelected;
@property (nonatomic, retain) IBOutlet UIDatePicker*    m_DatePicker;

@end
