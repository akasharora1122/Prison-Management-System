//
//  Search_DateVC.m
//  Hopula
//
//  Created by Techwin Labs on 17/02/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "Search_DateVC.h"
#import <Parse/Parse.h>
#import "MenuViewController.h"

@interface Search_DateVC ()

@end

@implementation Search_DateVC
@synthesize m_AnyDateButton, m_ContainerView, m_DatePicker, m_FromButton, m_NextMonthButton, m_NextWeekButton, m_ToButton;
@synthesize m_othertableview;

int isFromButton = 0;

#pragma mark - Life Cycle Methods

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

#pragma mark - 

- (IBAction)toButtonPressed:(id)sender {
    isFromButton = 0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [m_ContainerView setFrame:CGRectMake(0, 320, 320, 250)];
    [UIView commitAnimations];

}

- (IBAction)fromButtonPressed:(id)sender {
    isFromButton = 1;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [m_ContainerView setFrame:CGRectMake(0, 320, 320, 250)];
    [UIView commitAnimations];
}

- (IBAction)cancelButtonPressed:(id)sender {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [m_ContainerView setFrame:CGRectMake(0, 580, 320, 250)];
    [UIView commitAnimations];
}

- (IBAction)doneButtonPressed:(id)sender {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [m_ContainerView setFrame:CGRectMake(0, 580, 320, 250)];
    [UIView commitAnimations];
    
    NSDate *myDate = m_DatePicker.date;
    
    //Date Formatter
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MMM/dd/yyyy"];
    NSString *dateis = [dateFormat stringFromDate:myDate];
    if (isFromButton == 1) {
        [m_FromButton setTitle:dateis forState:UIControlStateNormal];
    } else {
        [m_ToButton setTitle:dateis forState:UIControlStateNormal];
    }
    
    if ([[m_FromButton titleForState:UIControlStateNormal] length] > 4 && [[m_ToButton titleForState:UIControlStateNormal] length] > 4)
    {
        NSMutableArray *dummyArray = [[NSMutableArray alloc] init];
        
        [m_NextMonthButton setBackgroundImage:[UIImage imageNamed:@"Date_checkMark"] forState:UIControlStateNormal];
        [m_NextWeekButton setBackgroundImage:nil forState:UIControlStateNormal];
        [m_AnyDateButton setBackgroundImage:nil forState:UIControlStateNormal];
        [m_Array removeAllObjects];
        m_Array = [[NSMutableArray alloc] init];
        tableData = nil;
        
        PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"MMM/dd/yyyy"];
        NSDate *dateis = [dateFormat dateFromString:[m_FromButton titleForState:UIControlStateNormal]];
        NSDate *dateis1 = [dateFormat dateFromString:[m_ToButton titleForState:UIControlStateNormal]];
    
        
        NSDateFormatter *format = [[NSDateFormatter alloc] init];
        [format setDateFormat:@"dd-MMM-yyyy"];
        
                //    [query whereKey:@"date_of_releasing" greaterThanOrEqualTo:dateSting];
        //    [query whereKey:@"date_of_releasing" lessThanOrEqualTo:dateSting1];

        [query whereKey:@"Date_Releasing" greaterThanOrEqualTo:dateis];
        [query whereKey:@"Date_Releasing" lessThanOrEqualTo:dateis1];
        
        
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
            if (!err) {
                if ([array count] > 0) {
                    [dummyArray addObjectsFromArray:array];
                    //[self.m_othertableview reloadData];
                    
                    for (int x= 0; x<[dummyArray count]; x++) {
                        
                        PFQuery *query1 = [PFQuery queryWithClassName:@"prisoner_details"];
                        [query1 getObjectInBackgroundWithId:[[dummyArray objectAtIndex:x] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
                            if (!error) {
                                NSLog(@"Success %@",val);
                                
                                [m_Array addObject:val];
                                
                            }
                            else {
                                NSLog(@"Fail");
                                
                            }
                            [m_othertableview reloadData];
                        }];
                    }
                    
                } else {
                    [m_othertableview reloadData];
                }
            }
            else {
                NSLog(@"Fail");
                
            }
            
        }];
    }
    
}

- (IBAction)backButtonPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)anyDateButtonPressed:(id)sender {
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];

    
    [m_AnyDateButton setBackgroundImage:[UIImage imageNamed:@"Date_checkMark"] forState:UIControlStateNormal];
    [m_NextWeekButton setBackgroundImage:nil forState:UIControlStateNormal];
    [m_NextMonthButton setBackgroundImage:nil forState:UIControlStateNormal];
    
    [m_Array removeAllObjects];
    m_Array = [[NSMutableArray alloc] init];
    tableData = nil;

    PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
    NSDate *date = [NSDate date];
    NSString *dateSting = [[NSString alloc] init];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"dd-MMM-yyyy"];
    
    dateSting = [format stringFromDate:date];
    NSLog(@"date us %@",dateSting);
    
    NSTimeInterval AN_HOUR_AGO = 1; // in seconds
    NSTimeInterval AN_HOUR_AGO1 = 1*60*60*24*1; // in seconds
    [query whereKey:@"Date_Releasing" greaterThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO]];
    [query whereKey:@"Date_Releasing" lessThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO1]];

    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            if ([array count] > 0) {
                [dummyArray addObjectsFromArray:array];
                //[self.m_othertableview reloadData];
                
                for (int x= 0; x<[dummyArray count]; x++) {
                    
                    PFQuery *query1 = [PFQuery queryWithClassName:@"prisoner_details"];
                    [query1 getObjectInBackgroundWithId:[[dummyArray objectAtIndex:x] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
                        if (!error) {
                            NSLog(@"Success %@",val);
                            
                            [m_Array addObject:val];
                            
                        }
                        else {
                            NSLog(@"Fail");
                            
                        }
                        [m_othertableview reloadData];
                    }];
                }
                
            } else {
                [m_othertableview reloadData];
            }
        }
        else {
            NSLog(@"Fail");
            
        }
        
    }];
    
}

+ (NSString *)setDateComingFromServer: (NSString *) dateToPass {
    NSDateFormatter *dateFormatter  =   [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd, HH:mm:ss"];
    
    NSDate *yourDate                =   [dateFormatter dateFromString:dateToPass];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-yyyy"];
    
    NSString *dateis = [dateFormat stringFromDate:yourDate];
    return dateis;
}




- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [m_Array count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *TableIdentifier = @"TableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TableIdentifier];
    }
    
    for (UIView *view in cell.contentView.subviews) {
        [view removeFromSuperview];
    }
    
    
    PFObject *testObject= [m_Array objectAtIndex:indexPath.row];
    //cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]];
    
    PFFile *image1 = (PFFile *)[[m_Array objectAtIndex:indexPath.row ] objectForKey:@"photo"];
    //    cell.imageView.image = [UIImage imageWithData:image1.getData];
    
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, 0, 250, 40)];
    [nameLabel setText:[NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]]];
    [nameLabel setBackgroundColor:[UIColor clearColor]];
    [nameLabel setTextColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:nameLabel];
    
    UIImageView *imageview  = [[UIImageView alloc] initWithFrame:CGRectMake(250, 1, 42, 42)];
    [imageview setImage:[UIImage imageWithData:image1.getData]];
    [cell.contentView addSubview:imageview];
    
    UILabel *separaterLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 44, 320, 2)];
    [separaterLabel setBackgroundColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:separaterLabel];

    
    /*
     PFQuery *query = [PFQuery queryWithClassName:@"prisoner_details"];
     [query getObjectInBackgroundWithId:[[tableData objectAtIndex:indexPath.row] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
     if (!error) {
     NSLog(@"Success %@",val);
     
     //cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]];
     
     PFFile *image1 = (PFFile *)[val objectForKey:@"photo"];
     //    cell.imageView.image = [UIImage imageWithData:image1.getData];
     
     
     UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, 0, 250, 40)];
     [nameLabel setText:[NSString stringWithFormat:@"%@ %@",[val objectForKey:@"first_Name"],[val objectForKey:@"last_name"]]];
     [nameLabel setBackgroundColor:[UIColor clearColor]];
     [nameLabel setTextColor:[UIColor darkGrayColor]];
     [cell.contentView addSubview:nameLabel];
     
     UIImageView *imageview  = [[UIImageView alloc] initWithFrame:CGRectMake(250, 1, 42, 42)];
     [imageview setImage:[UIImage imageWithData:image1.getData]];
     [cell.contentView addSubview:imageview];
     
     }
     else {
     NSLog(@"Fail");
     
     }
     }];
     
     //[query whereKey:@"ObjectId" equalTo:[[tableData objectAtIndex:indexPath.row] objectForKey:@"prisoner_id"]];
     [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
     
     }];
     
     */
    
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%@",[m_Array objectAtIndex:indexPath.row]);
    NSLog(@"%@",[m_Array objectAtIndex:indexPath.row]);
    
    MenuViewController *vc = [[MenuViewController alloc] initWithNibName:nil bundle:nil];
    
    //If we want to display already existing entry of prisoner set arefieldoccupied to yes
    vc.areFieldsOccipoed = @"Yes";
    PFObject *testObject= [m_Array objectAtIndex:indexPath.row];
    vc.fileDetails = testObject;
    
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)nextweekButtonPressed:(id)sender {
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];

    
    [m_NextWeekButton setBackgroundImage:[UIImage imageNamed:@"Date_checkMark"] forState:UIControlStateNormal];
    [m_NextMonthButton setBackgroundImage:nil forState:UIControlStateNormal];
    [m_AnyDateButton setBackgroundImage:nil forState:UIControlStateNormal];
    
    [m_Array removeAllObjects];
    m_Array = [[NSMutableArray alloc] init];
    tableData = nil;
    
    PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
    NSDate *date = [NSDate date];
    
    NSString *dateSting = [[NSString alloc] init];

    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"dd-MMM-yyyy"];
    
    dateSting = [format stringFromDate:date];
    
    NSTimeInterval AN_HOUR_AGO = -1; // in seconds
    NSTimeInterval AN_HOUR_AGO1 = 1*60*60*24*7; // in seconds
    [query whereKey:@"Date_Releasing" greaterThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO]];
    [query whereKey:@"Date_Releasing" lessThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO1]];

    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            if ([array count] > 0) {
                [dummyArray addObjectsFromArray:array];
                //[self.m_othertableview reloadData];
                
                for (int x= 0; x<[dummyArray count]; x++) {
                    
                    PFQuery *query1 = [PFQuery queryWithClassName:@"prisoner_details"];
                    [query1 getObjectInBackgroundWithId:[[dummyArray objectAtIndex:x] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
                        if (!error) {
                            NSLog(@"Success %@",val);
                            
                            [m_Array addObject:val];

                        }
                        else {
                            NSLog(@"Fail");
                            
                        }
                        [m_othertableview reloadData];
                    }];
                }
                
            } else {
                [m_othertableview reloadData];
            }
        }
        else {
            NSLog(@"Fail");
            
        }
        
    }];

}

- (IBAction)nextMonthButtonPressed:(id)sender {
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];

    [m_NextMonthButton setBackgroundImage:[UIImage imageNamed:@"Date_checkMark"] forState:UIControlStateNormal];
    [m_NextWeekButton setBackgroundImage:nil forState:UIControlStateNormal];
    [m_AnyDateButton setBackgroundImage:nil forState:UIControlStateNormal];
    [m_Array removeAllObjects];
    m_Array = [[NSMutableArray alloc] init];
    tableData = nil;
    
    PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
    NSDate *date = [NSDate date];
    int daysToAdd = 30;
    NSDate *newDate1 = [date dateByAddingTimeInterval:60*60*24*daysToAdd];
    
    NSString *dateSting = [[NSString alloc] init];
    NSString *dateSting1 = [[NSString alloc] init];
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"dd-MMM-yyyy"];
    
    dateSting = [format stringFromDate:date];
    dateSting1 = [format stringFromDate:newDate1];
    
    NSLog(@"date us %@ %@",dateSting, dateSting1);
//    [query whereKey:@"date_of_releasing" greaterThanOrEqualTo:dateSting];
//    [query whereKey:@"date_of_releasing" lessThanOrEqualTo:dateSting1];
//    
    NSTimeInterval AN_HOUR_AGO = -1; // in seconds
    NSTimeInterval AN_HOUR_AGO1 = 1*60*60*24*30; // in seconds
    [query whereKey:@"Date_Releasing" greaterThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO]];
    [query whereKey:@"Date_Releasing" lessThanOrEqualTo:[NSDate dateWithTimeIntervalSinceNow: AN_HOUR_AGO1]];

    
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            if ([array count] > 0) {
                [dummyArray addObjectsFromArray:array];
                //[self.m_othertableview reloadData];
                
                for (int x= 0; x<[dummyArray count]; x++) {
                    
                    PFQuery *query1 = [PFQuery queryWithClassName:@"prisoner_details"];
                    [query1 getObjectInBackgroundWithId:[[dummyArray objectAtIndex:x] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
                        if (!error) {
                            NSLog(@"Success %@",val);
                            
                            [m_Array addObject:val];
                            
                        }
                        else {
                            NSLog(@"Fail");
                            
                        }
                        [m_othertableview reloadData];
                    }];
                }
                
            } else {
                [m_othertableview reloadData];
            }
        }
        else {
            NSLog(@"Fail");
            
        }
        
    }];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
