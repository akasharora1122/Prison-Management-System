//
//  PrisonerViewController.m
//  PM
//
//  Created by Techwin Labs on 04/06/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "PrisonerViewController.h"
#import "MenuViewController.h"
#import "crimeviewcontroller.h"
#import "SearchReleasedPrisonerViewController.h"
#import "Search_DateVC.h"
#import "ParoleViewController.h"
#import "AboutViewController.h"

@interface PrisonerViewController ()

@end

@implementation PrisonerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





- (IBAction)newPrisonerPressed:(id)sender {
    MenuViewController *vc = [[MenuViewController alloc] initWithNibName:nil bundle:nil];
    //If we want to add new entry
    vc.areFieldsOccipoed = @"No";
    [self.navigationController pushViewController:vc animated:YES];
}




- (IBAction)existingPrisonerPressed:(id)sender {
    crimeviewcontroller *vc = [[crimeviewcontroller alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}


- (IBAction)releasingDateofPrisoner:(id)sender {
    SearchReleasedPrisonerViewController *vc = [[SearchReleasedPrisonerViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];

}

- (IBAction)rangeOfDates:(id)sender {
    Search_DateVC *vc = [[Search_DateVC alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];

}


- (IBAction)paroleViewPressed:(id)sender {
    ParoleViewController *vc = [[ParoleViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];

}

- (IBAction)aboutPressed:(id)sender {
    AboutViewController *vc = [[AboutViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];

}

//-(IBAction)addexistingPressed:(id)sender {
  //  criminalviewcontroller *vc = [[CriminalRecordViewController alloc] initWithNibName:nil bundle:nil];
    //[self.navigationController pushViewController:vc animated:YES];
//}







/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
