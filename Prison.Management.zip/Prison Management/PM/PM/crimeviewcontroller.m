//
//  crimeviewcontroller.m
//  PM
//
//  Created by Techwin Labs on 06/06/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "crimeviewcontroller.h"
#import <Parse/Parse.h>

@interface crimeviewcontroller ()

@end

@implementation crimeviewcontroller

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    PFQuery *query = [PFQuery queryWithClassName:@"prisoner_details"];
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            NSLog(@"Success %@",array);
            if ([array count] > 0) {
                tableData = [[NSArray alloc] initWithArray:array];
                [self.m_othertableview reloadData];
            }
        }
        else {
            NSLog(@"Fail");
            
        }
    }];

    
//    tableData = [[NSArray alloc] initWithObjects:@"asd",nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = NO;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [tableData count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *TableIdentifier = @"TableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TableIdentifier];
    }

    for (UIView *view in cell.contentView.subviews) {
        [view removeFromSuperview];
    }
    
    
    PFObject *testObject= [tableData objectAtIndex:indexPath.row];
    //cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]];
    
    PFFile *image1 = (PFFile *)[[tableData objectAtIndex:indexPath.row ] objectForKey:@"photo"];
//    cell.imageView.image = [UIImage imageWithData:image1.getData];
    
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, 0, 250, 40)];
    [nameLabel setText:[NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]]];
    [nameLabel setBackgroundColor:[UIColor clearColor]];
    [nameLabel setTextColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:nameLabel];
    
    UIImageView *imageview  = [[UIImageView alloc] initWithFrame:CGRectMake(250, 1, 42, 42)];
    [imageview setImage:[UIImage imageWithData:image1.getData]];
    [cell.contentView addSubview:imageview];
    
    UILabel *separaterLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 44, 320, 2)];
    [separaterLabel setBackgroundColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:separaterLabel];

    
    return cell;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%@",[tableData objectAtIndex:indexPath.row]);
    
    MenuViewController *vc = [[MenuViewController alloc] initWithNibName:nil bundle:nil];

    //If we want to display already existing entry of prisoner set arefieldoccupied to yes
    vc.areFieldsOccipoed = @"Yes";
    PFObject *testObject= [tableData objectAtIndex:indexPath.row];
    vc.fileDetails = testObject;
    
    [self.navigationController pushViewController:vc animated:YES];
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
