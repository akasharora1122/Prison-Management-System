//
//  PhysicalAppearanceViewController.m
//  PM
//
//  Created by Techwin Labs on 26/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "PhysicalAppearanceViewController.h"
#import <Parse/Parse.h>
@interface PhysicalAppearanceViewController ()

@end

@implementation PhysicalAppearanceViewController
@synthesize _IDofPrisonerStrings,_criminalIDs;



- (void)viewDidLoad {
    [super viewDidLoad];
  // Do any additional setup after loading the view from its nib.
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    if ([self.areallthefieldsoccupied isEqualToString:@"Yes"]) {
        
        PFQuery *query = [PFQuery queryWithClassName:@"physical_appearance"];
        [query whereKey:@"prisoner_id" equalTo:_criminalIDs];
        NSLog(@"report is %@",_criminalIDs);
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
            if (!err) {
                NSLog(@"Success %@",array);
                if ([array count] > 0) {
                    self.m_height.text =[[array objectAtIndex:0] objectForKey:@"height"];
                    self.m_weight.text =[[array objectAtIndex:0] objectForKey:@"weight"];
                    self.m_complexion.text=[[array objectAtIndex:0] objectForKey:@"complexion"];
                    self.m_eye.text =[[array objectAtIndex:0] objectForKey:@"eye"];
                    self.m_hair.text =[[array objectAtIndex:0] objectForKey:@"hair"];
                    
                    
                }
            }
            else {
                NSLog(@"Fail");
                
            }
        }];
        
        _m_save.hidden=YES;
        
    }
    else {
        self.m_height.text=@"";
        self.m_weight.text=@"";
        self.m_complexion.text=@"";
        self.m_eye.text=@"";
        self.m_hair.text=@"";
        self.m_save.hidden=NO;
        
        /*if ([[NSUserDefaults standardUserDefaults] objectForKey:@"Crime"]) {
         _m_labels.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"Crime"];
         }*/
        
        
    }

    
}


- (IBAction)savebuttonPressed:(id)sender {
    
    if (([_m_height.text length]>1)&&([_m_eye.text length]>1) &&([_m_complexion.text length]>1)&&([_m_hair.text length]>1)&&([_m_weight.text length]>1)){

                    
                        //Save
                    PFObject *testObject = [PFObject objectWithClassName:@"physical_appearance"];
                    testObject[@"height"] = _m_height.text;
                    testObject[@"weight"] = _m_weight.text;
                    testObject[@"complexion"] = _m_complexion.text;
                    testObject[@"eye"] = _m_eye.text;
                    testObject[@"hair"] = _m_hair.text;
                    testObject[@"prisoner_id"] = _criminalIDs ;
                    [testObject saveInBackground];
                        
                        
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Saved Successfully!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [alert show];
        
            
            
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Invalid Entry!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
            [alert show];
        }
    } /*else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"invalid entry!" delegate:nil //cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }*/
//}


             





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
