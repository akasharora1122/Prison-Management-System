//
//  Search_DateVC.h
//  Hopula
//
//  Created by Techwin Labs on 17/02/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Search_DateVC : UIViewController<UITableViewDelegate, UITableViewDataSource>

{
    NSArray *tableData;
    NSMutableArray* m_Array;
}


@property (strong, nonatomic) IBOutlet UITableView *m_othertableview;

@property (nonatomic, retain) IBOutlet UIButton*    m_ToButton;
@property (nonatomic, retain) IBOutlet UIButton*    m_FromButton;
@property (nonatomic, retain) IBOutlet UIDatePicker*    m_DatePicker;
@property (nonatomic, retain) IBOutlet UIView*      m_ContainerView;
@property (nonatomic, retain) IBOutlet UIButton*    m_AnyDateButton;
@property (nonatomic, retain) IBOutlet UIButton*    m_NextWeekButton;
@property (nonatomic, retain) IBOutlet UIButton*    m_NextMonthButton;

+ (NSString *)setDateComingFromServer: (NSString *) dateToPass;


@end
