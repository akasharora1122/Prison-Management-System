//
//  CriminalRecordViewController.h
//  PM
//
//  Created by Techwin Labs on 26/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tableViewController.h"
#import "MenuViewController.h"
#import<Parse/Parse.h>


@interface CriminalRecordViewController :UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    UIImagePickerController *picker;
    UIImage *image;
    IBOutlet UIImageView *imageview;

}
@property (strong, nonatomic) IBOutlet UIButton *m_crimecategory;
@property (strong, nonatomic) IBOutlet UILabel *m_labels;
@property (strong, nonatomic) IBOutlet UIButton *m_dateofconviction;
@property (strong, nonatomic) IBOutlet UIButton *m_days;
@property (strong, nonatomic) IBOutlet UIButton *m_dateofreleasing;

@property (nonatomic, copy) NSString* m_selectedCellText;
@property (strong, nonatomic) IBOutlet UITextView *m_detail;
@property (strong, nonatomic) IBOutlet UIButton *m_dateofcommittingcrime;
@property (strong, nonatomic) IBOutlet UIButton *m_dateofreportcrime;
@property (strong, nonatomic) IBOutlet UIView *m_pickerview1;
@property (strong, nonatomic) IBOutlet UIDatePicker *m_datepickerview1;
@property (strong, nonatomic) IBOutlet UIView *m_pickerview;
@property (strong, nonatomic) IBOutlet UIDatePicker *m_datepickerview;
@property (strong, nonatomic) IBOutlet UIView *m_pickerview2;

@property (strong, nonatomic) IBOutlet UIView *m_pickerview3;
@property (strong, nonatomic) IBOutlet UIDatePicker *m_datepickerview2;

@property (strong, nonatomic) IBOutlet UIDatePicker *m_datepickerview3;
@property (strong, nonatomic) IBOutlet UIButton *m_save;

@property (nonatomic, retain) NSString*             _IDofPrisonerString;

@property (strong, nonatomic) IBOutlet UITextField *m_actualreleasedate;

@property (strong,nonatomic) NSString*  areallfieldsoccupied;
@property (strong, nonatomic) PFObject                *fileDetails;
@property (strong,nonatomic) NSString*                  _criminalID;
@property (strong, nonatomic) IBOutlet UIButton *m_moreinfo;
@property (strong, nonatomic) NSDate*                m_ReleasingDateSelected;

@end
