//
//  AddParoleViewController.m
//  PM
//
//  Created by Techwin Labs on 04/08/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "AddParoleViewController.h"

@interface AddParoleViewController ()

@end

@implementation AddParoleViewController
@synthesize m_othertableview, m_ConvictSelected, m_DatePicker;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
    [self fetchAll];
}

- (void)fetchAll {
    m_ConvictSelected = -1;
    
    NSMutableArray *dummyArray = [[NSMutableArray alloc] init];
    
    [m_Array removeAllObjects];
    m_Array = [[NSMutableArray alloc] init];
    
    PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
    [query whereKey:@"Parole" equalTo:@"0"];
    
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            if ([array count] > 0) {
                [dummyArray addObjectsFromArray:array];
                //[self.m_othertableview reloadData];
                
                for (int x= 0; x<[dummyArray count]; x++) {
                    
                    PFQuery *query1 = [PFQuery queryWithClassName:@"prisoner_details"];
                    [query1 getObjectInBackgroundWithId:[[dummyArray objectAtIndex:x] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
                        if (!error) {
                            NSLog(@"Success %@",val);
                            
                            [m_Array addObject:val];
                            
                        }
                        else {
                            NSLog(@"Fail");
                            
                        }
                        [m_othertableview reloadData];
                    }];
                }
                
            } else {
                [m_othertableview reloadData];
            }
        }
        else {
            NSLog(@"Fail");
            
        }
        
    }];

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [m_Array count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *TableIdentifier = @"TableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TableIdentifier];
    }
    
    for (UIView *view in cell.contentView.subviews) {
        [view removeFromSuperview];
    }
    
    
    PFObject *testObject= [m_Array objectAtIndex:indexPath.row];
    //cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]];
    
    PFFile *image1 = (PFFile *)[[m_Array objectAtIndex:indexPath.row ] objectForKey:@"photo"];
    //    cell.imageView.image = [UIImage imageWithData:image1.getData];
    
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, 0, 250, 40)];
    [nameLabel setText:[NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]]];
    [nameLabel setBackgroundColor:[UIColor clearColor]];
    [nameLabel setTextColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:nameLabel];
    
    UIImageView *imageview  = [[UIImageView alloc] initWithFrame:CGRectMake(250, 1, 42, 42)];
    [imageview setImage:[UIImage imageWithData:image1.getData]];
    [cell.contentView addSubview:imageview];
    
    
    UILabel *separaterLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 44, 320, 2)];
    [separaterLabel setBackgroundColor:[UIColor darkGrayColor]];
    [cell.contentView addSubview:separaterLabel];
    /*
     PFQuery *query = [PFQuery queryWithClassName:@"prisoner_details"];
     [query getObjectInBackgroundWithId:[[tableData objectAtIndex:indexPath.row] objectForKey:@"prisoner_id"] block:^(PFObject *val, NSError *error) {
     if (!error) {
     NSLog(@"Success %@",val);
     
     //cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[testObject objectForKey:@"last_name"],[testObject objectForKey:@"first_name"]];
     
     PFFile *image1 = (PFFile *)[val objectForKey:@"photo"];
     //    cell.imageView.image = [UIImage imageWithData:image1.getData];
     
     
     UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(2, 0, 250, 40)];
     [nameLabel setText:[NSString stringWithFormat:@"%@ %@",[val objectForKey:@"first_Name"],[val objectForKey:@"last_name"]]];
     [nameLabel setBackgroundColor:[UIColor clearColor]];
     [nameLabel setTextColor:[UIColor darkGrayColor]];
     [cell.contentView addSubview:nameLabel];
     
     UIImageView *imageview  = [[UIImageView alloc] initWithFrame:CGRectMake(250, 1, 42, 42)];
     [imageview setImage:[UIImage imageWithData:image1.getData]];
     [cell.contentView addSubview:imageview];
     
     }
     else {
     NSLog(@"Fail");
     
     }
     }];
     
     //[query whereKey:@"ObjectId" equalTo:[[tableData objectAtIndex:indexPath.row] objectForKey:@"prisoner_id"]];
     [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
     
     }];
     
     */
    
    return cell;
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"%@",[m_Array objectAtIndex:indexPath.row]);
    NSLog(@"%@",[m_Array objectAtIndex:indexPath.row]);
    m_ConvictSelected = indexPath.row;
}


- (IBAction)saveButtonPressed:(id)sender {
    NSDate *myDate = self.m_DatePicker.date;
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];

    PFObject *testObject= [m_Array objectAtIndex:m_ConvictSelected];
    NSLog(@"tet are %@",testObject);

    PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
    [query whereKey:@"prisoner_id" equalTo:testObject.objectId];
    
    [query getFirstObjectInBackgroundWithBlock:^(PFObject * userStats, NSError *error) {
        if (!error) {
            // all objects, and object2ref data should be available
            
            NSLog(@"objects are %@",userStats);
            NSLog(@"wow are %@",userStats);

            
           // newObject[@"Parole"] = @"1";
            [userStats setObject:@"1" forKey:@"Parole"];
            userStats[@"actual_release_date"]=prettyVersion;
            [userStats saveInBackgroundWithBlock:^(BOOL success, NSError *error) {
                if (success) {
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success!" message:@"Parole Updated Successfully!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
                    [alert show];
                    [self fetchAll];
                }
                }];
;

        }
        else {
            NSLog(@"Error, %@ %@",error,[error userInfo]);
        }
    }];

    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
