//
//  MenuViewController.h
//  PM
//
//  Created by Techwin Labs on 25/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CriminalRecordViewController.h"
#import <Parse/Parse.h>

@interface MenuViewController : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITextFieldDelegate>{
    UIImagePickerController *picker;
    UIImage *image;
    IBOutlet UIImageView *imageview;
}
//-(IBAction)takephoto;
-(IBAction)chooseexisting;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldfirstname;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldlastname;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldphonenumber;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldaddress;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldstreet;
@property (strong, nonatomic) IBOutlet UITextField *m_textfieldcity;
@property (strong, nonatomic) IBOutlet UIDatePicker*    m_DatePicker;
@property (strong, nonatomic) IBOutlet UIView*              m_PickerView;
@property (strong, nonatomic) IBOutlet UIButton *       m_ProfileBtn;
@property (strong, nonatomic) IBOutlet UIButton*        m_DOBButton;

@property (strong, nonatomic) NSString*                areFieldsOccipoed;
@property (strong, nonatomic) PFObject                *fileDetails;
- (IBAction)cancelButtonPressed:(id)sender;
- (IBAction)saveButtonPressed:(id)sender;
- (IBAction)saveDetailsButtonPressed:(id)sender;
- (IBAction)dobPressed:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *m_save;
@property (strong, nonatomic) IBOutlet UIButton *m_moreinfo;

@end
