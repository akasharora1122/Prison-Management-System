//
//  PhysicalAppearanceViewController.h
//  PM
//
//  Created by Techwin Labs on 26/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<Parse/Parse.h>
@interface PhysicalAppearanceViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *m_height;
@property (strong, nonatomic) IBOutlet UITextField *m_weight;
@property (strong, nonatomic) IBOutlet UITextField *m_complexion;
@property (strong, nonatomic) IBOutlet UITextField *m_hair;
@property (strong, nonatomic) IBOutlet UITextField *m_eye;
@property (strong, nonatomic) IBOutlet UIButton *m_save;
@property (strong, nonatomic) NSString*                areallthefieldsoccupied;
@property (strong,nonatomic) NSString*                  _criminalIDs;
@property (nonatomic, retain) NSString*             _IDofPrisonerStrings;
@end
