//
//  LoginViewController.m
//  PM
//
//  Created by Techwin Labs on 25/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "LoginViewController.h"
#import "PrisonerViewController.h"
#import "SignupViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize m_EmailTextfield, m_PassTextfield, m_LoginButton;

- (void)viewDidLoad {
    [super viewDidLoad];

    
    // Do any additional setup after loading the view from its nib.
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = [NSDate dateWithTimeIntervalSinceNow:05];
    localNotification.alertBody = @"Local Notification in iOS8";
    localNotification.timeZone = [NSTimeZone systemTimeZone];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = YES;
}

-(IBAction)buttonpressed:(id)sender{
    
    if ([self.m_EmailTextfield.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"email id cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }
   else  if(([self.m_PassTextfield.text length]<1) && ([self.m_EmailTextfield.text length]>=1))
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"ERROR" message:@"password cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    } else {
        
        PFQuery *query = [PFQuery queryWithClassName:@"Login"];
        [query whereKey:@"Email" equalTo:m_EmailTextfield.text];
        [query whereKey:@"Password" equalTo:m_PassTextfield.text];
        
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
            if (!err) {
                NSLog(@"Success %@",array);
                if ([array count] > 0) {
                    
                    [[NSUserDefaults standardUserDefaults] setObject:m_EmailTextfield.text forKey:@"LoggedinUser"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    PrisonerViewController *vc = [[PrisonerViewController alloc] initWithNibName:nil bundle:nil];
                    [self.navigationController pushViewController:vc animated:YES];
                } else {
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Wrong Email & Password Combination!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                    [alert show];
                    
                    NSLog(@"Fail");

                }
            }
            else {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Try Again!" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [alert show];

                NSLog(@"Fail");
                
            }
        }];

    }
}


-(IBAction)signupBUttonPressed:(id)sender {
    SignupViewController *vc = [[SignupViewController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - Text field Deletgates

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder]; //to resign keyboard
    return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
