//
//  LoginViewController.h
//  PM
//
//  Created by Techwin Labs on 25/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface LoginViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *m_EmailTextfield;
@property (strong, nonatomic) IBOutlet UITextField *m_PassTextfield;
@property (strong, nonatomic) IBOutlet UIButton *m_LoginButton;

@end
