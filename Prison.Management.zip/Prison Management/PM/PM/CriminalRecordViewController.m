//
//  CriminalRecordViewController.m
//  PM
//
//  Created by Techwin Labs on 26/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "CriminalRecordViewController.h"
#import <Parse/Parse.h>
#import "PhysicalAppearanceViewController.h"
@interface CriminalRecordViewController ()

@end

@implementation CriminalRecordViewController
@synthesize _IDofPrisonerString,fileDetails,_criminalID, m_ReleasingDateSelected;




-(IBAction)moreinfopressed:(id)sender{
    
    
    PhysicalAppearanceViewController *vc = [[PhysicalAppearanceViewController alloc] initWithNibName:nil bundle:nil];
    
    //If we want to display already existing entry of prisoner set arefieldoccupied to yes
    vc.areallthefieldsoccupied = @"Yes";
    vc._criminalIDs = _criminalID;
  //  vc._prisonerid = testObject.objectId;
    [self.navigationController pushViewController:vc animated:YES];
    
    
}





- (void)viewDidLoad{
    
    [super viewDidLoad];

        
    }
    





//- (void)viewDidLoad:(BOOL)animated {
  // }


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
    
    self.navigationController.navigationBarHidden = NO;
    
    // Do any additional setup after loading the view from its nib.
    // NSLog(@"%received is @",_criminalID);
    if ([self.areallfieldsoccupied isEqualToString:@"Yes"]) {
        
        PFQuery *query = [PFQuery queryWithClassName:@"Crime_Details"];
        [query whereKey:@"prisoner_id" equalTo:_criminalID];
        NSLog(@"report is %@",_criminalID);
        [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
            if (!err) {
                NSLog(@"Success %@",array);
                if ([array count] > 0) {
                    self.m_labels.text =[[array objectAtIndex:0] objectForKey:@"crime_category"];
                    [self.m_dateofcommittingcrime setTitle:[[array objectAtIndex:0] objectForKey:@"date_of_committing_crime"] forState:UIControlStateNormal];
                    
                    NSDate *dateOfReleasing = [[array objectAtIndex:0] objectForKey:@"Date_Releasing"];
                    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
                    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
                    
                    [self.m_dateofreleasing setTitle:[NSString stringWithFormat:@"%@", [dateFormat stringFromDate:dateOfReleasing]] forState:UIControlStateNormal];
                    [self.m_dateofconviction setTitle:[[array objectAtIndex:0] objectForKey:@"date_of_conviction"] forState:UIControlStateNormal];
                    [self.m_dateofreportcrime setTitle:[[array objectAtIndex:0] objectForKey:@"date_of_report_crime"] forState:UIControlStateNormal];
                    self.m_actualreleasedate.text = [[array objectAtIndex:0] objectForKey:@"actual_release_date"];
                    self.m_detail.text=[[array objectAtIndex:0] objectForKey:@"detail"];
                    
                }
            }
            else {
                NSLog(@"Fail");
                
            }
        }];
        
        _m_save.hidden=YES;
        _m_moreinfo.hidden=NO;
    }
    else {
        if ([[NSUserDefaults standardUserDefaults] objectForKey:@"Crime"]) {
            self.m_labels.text=[[NSUserDefaults standardUserDefaults] objectForKey:@"Crime"];
        }
        
        [self.m_dateofcommittingcrime setTitle:@"date_of_committing_crime" forState:UIControlStateNormal];
        [self.m_dateofreleasing setTitle:@"Date_Releasing" forState:UIControlStateNormal];
        self.m_actualreleasedate.text = @"";
        [self.m_dateofconviction setTitle:@"date_of_conviction" forState:UIControlStateNormal];
        [self.m_dateofreportcrime setTitle:@"date_of_report_crime" forState:UIControlStateNormal];
        self.m_detail.text=@"";
        self.m_save.hidden=NO;
        _m_moreinfo.hidden=YES;
    }
    
    

    
}

- (void)viewWillAppear {
    [super viewWillAppear:YES];
    
    
   }

- (void)didReceiveMemoryWarning:(BOOL)animated {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)CrimeCategoryButtonPressed:(id)sender {
    
        tableViewController  *vc2 = [[tableViewController alloc] initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:vc2 animated:YES];
    
    
 }

- (IBAction)cancelButtonPressed:(id)sender {
    [self.m_pickerview removeFromSuperview];
    [self.m_pickerview1 removeFromSuperview];
    [self.m_pickerview2 removeFromSuperview];
    [self.m_pickerview3 removeFromSuperview];

    
}

- (IBAction)assignValues:(id)sender {
    NSDate *myDate = self.m_datepickerview.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    
    [self.m_dateofconviction setTitle:prettyVersion forState:UIControlStateNormal];
    
    [self.m_pickerview removeFromSuperview];
 
    
}



- (IBAction)assignValues1:(id)sender {
    NSDate *myDate = self.m_datepickerview1.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    
    [self.m_dateofreportcrime  setTitle:prettyVersion forState:UIControlStateNormal];
    
    [self.m_pickerview1 removeFromSuperview];
    
    
}
- (IBAction)convictionButtonPressed:(id)sender {
    self.m_pickerview.center = self.view.center;
    [self.view addSubview:self.m_pickerview];

    
    
}




- (IBAction)reportcrimeButtonPressed:(id)sender {
    self.m_pickerview1.center = self.view.center;
    [self.view addSubview:self.m_pickerview1];
    
}



- (IBAction)committingcrimeButtonPressed:(id)sender {
    self.m_pickerview2.center = self.view.center;
    [self.view addSubview:self.m_pickerview2];
    
}



- (IBAction)assignValues2:(id)sender {
    NSDate *myDate = self.m_datepickerview2.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    
    [self.m_dateofcommittingcrime  setTitle:prettyVersion forState:UIControlStateNormal];
    
    [self.m_pickerview2 removeFromSuperview];
    
    
}






- (IBAction)releaseButtonPressed:(id)sender {
    self.m_pickerview3.center = self.view.center;
    [self.view addSubview:self.m_pickerview3];
    
}



- (IBAction)assignValues3:(id)sender {
    NSDate *myDate = self.m_datepickerview3.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    m_ReleasingDateSelected = myDate;
    [self.m_dateofreleasing  setTitle:prettyVersion forState:UIControlStateNormal];
    
    [self.m_pickerview3 removeFromSuperview];
    
    
}





- (IBAction)saveButtonPressed:(id)sender {
    
    NSString *str = [_m_dateofreleasing titleForState:UIControlStateNormal];

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MMM-YYYY"];
    NSDate *reportingDate = [dateFormatter dateFromString:str];
    
    
    PFObject *testObject = [PFObject objectWithClassName:@"Crime_Details"];
    ;
    
    testObject[@"prisoner_id"] = _IDofPrisonerString ;
    testObject[@"crime_catgory"] = _m_labels.text;
    testObject[@"date_of_committing_crime"] =[_m_dateofcommittingcrime titleForState:UIControlStateNormal];
    testObject[@"date_of_conviction"] =[_m_dateofconviction titleForState:UIControlStateNormal];
    
    
    NSDateFormatter * dateFormatter1 = [[NSDateFormatter alloc]init];
    [dateFormatter1 setDateFormat:@"dd-MMM-YYYY"];
    
    
    NSDate * dateNotFormatted = [dateFormatter1 dateFromString:str];
    
    testObject[@"Date_Releasing"] =  m_ReleasingDateSelected;
    
    NSLog(@"wasasd %@ %@",[_m_dateofreleasing titleForState:UIControlStateNormal],dateNotFormatted);
    
    testObject[@"actual_release_date"] = _m_actualreleasedate.text;
    testObject[@"details"] = _m_detail.text;
    testObject [@"date_of_report_crime"] = [_m_dateofreportcrime titleForState:UIControlStateNormal];

    [testObject saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
        
        if (succeeded){
            NSLog(@"Object Uploaded!");
            PhysicalAppearanceViewController *vc = [[PhysicalAppearanceViewController alloc]initWithNibName:nil bundle:nil];
            vc._criminalIDs = _criminalID;
vc.areallthefieldsoccupied = @"No";
          [self.navigationController pushViewController:vc animated:YES];
   
            
        }
        else{
            NSString *errorString = [[error userInfo] objectForKey:@"error"];
            NSLog(@"Error: %@", errorString);
        }
    }];

}





/*
 #pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
