//
//  SearchReleasedPrisonerViewController.h
//  PM
//
//  Created by Techwin Labs on 08/07/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchReleasedPrisonerViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSArray *tableData;
    NSMutableArray* m_Array;
}


@property (strong, nonatomic) IBOutlet UITableView *m_othertableview;
@property (strong, nonatomic) IBOutlet UIButton*    m_DateButton;
@property (strong, nonatomic) IBOutlet UIDatePicker *m_datepickerview;

+ (NSString *)setDateComingFromServer: (NSString *) dateToPass;


@end
