//
//  crimeviewcontroller.h
//  PM
//
//  Created by Techwin Labs on 06/06/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuViewController.h"
@interface crimeviewcontroller :  UIViewController<UITableViewDelegate, UITableViewDataSource>
{
    NSArray *tableData;
}


@property (strong, nonatomic) IBOutlet UITableView *m_othertableview;


@end
