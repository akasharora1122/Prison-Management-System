//
//  PrisonerViewController.h
//  PM
//
//  Created by Techwin Labs on 04/06/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrisonerViewController : UIViewController

@end
