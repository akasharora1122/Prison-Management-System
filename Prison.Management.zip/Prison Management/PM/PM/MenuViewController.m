//
//  MenuViewController.m
//  PM
//
//  Created by Techwin Labs on 25/05/15.
//  Copyright (c) 2015 TechwinLabs. All rights reserved.
//

#import "MenuViewController.h"
#import "CriminalRecordViewController.h"
@interface MenuViewController ()

@end

@implementation MenuViewController
@synthesize areFieldsOccipoed, fileDetails;

/*-(IBAction)takephoto{
    picker = [[UIImagePickerController alloc]init];
    picker.delegate=self;
    [picker setSourceType:UIImagePickerControllerSourceTypeCamera ];
    [self presentViewController:picker animated:YES completion:NULL];
  //  [picker  release];
}*/
-(IBAction)chooseexisting{
    picker = [[UIImagePickerController alloc]init];
    picker.delegate=self;
    [picker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary ];
    [self presentViewController:picker animated:YES completion:NULL];
    //[picker2  release];

}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    image=[info objectForKey:UIImagePickerControllerOriginalImage];
    [self.m_ProfileBtn setBackgroundImage:image forState:UIControlStateNormal];
    [self.m_ProfileBtn setTitle:@"" forState:UIControlStateNormal];
    [self dismissViewControllerAnimated:YES completion:NULL];
    
}


-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:NULL];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _m_DatePicker.maximumDate=[NSDate date];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.navigationController.navigationBarHidden = NO;

    if ([areFieldsOccipoed isEqualToString:@"Yes"]) {
        self.m_textfieldaddress.text =[fileDetails objectForKey:@"address"];
        self.m_textfieldcity.text = [fileDetails objectForKey:@"city"];
        self.m_textfieldfirstname.text = [fileDetails objectForKey:@"first_name"];
        self.m_textfieldlastname.text = [fileDetails objectForKey:@"last_name"];
        self.m_textfieldphonenumber.text  = [fileDetails objectForKey:@"city"];
        self.m_textfieldstreet.text = [fileDetails objectForKey:@"street"];
        [self.m_DOBButton setTitle:[fileDetails objectForKey:@"dob"] forState:UIControlStateNormal];
        PFFile *firstImage = (PFFile *)[fileDetails objectForKey:@"photo"];
        [self.m_ProfileBtn setTitle:@"" forState:UIControlStateNormal];
        [self.m_ProfileBtn setBackgroundImage:[UIImage imageWithData:firstImage.getData] forState:UIControlStateNormal];
        _m_save.hidden=YES;
        _m_moreinfo.hidden = NO;

    } else {
        self.m_textfieldaddress.text =@"";
        self.m_textfieldcity.text = @"";
        self.m_textfieldfirstname.text = @"";
        self.m_textfieldlastname.text = @"";
        self.m_textfieldphonenumber.text  = @"";
        self.m_textfieldstreet.text = @"";
                [self.m_ProfileBtn setTitle:@"Photo" forState:UIControlStateNormal];
        [self.m_DOBButton setTitle:@"D.O.B" forState:UIControlStateNormal];
        _m_save.hidden = NO;
        _m_moreinfo.hidden = YES;
    }
}



-(IBAction)moreinfopressed:(id)sender{
    

CriminalRecordViewController *vc1= [[CriminalRecordViewController alloc] initWithNibName:nil bundle:nil];

//If we want to display already existing entry of prisoner set arefieldoccupied to yes
vc1.areallfieldsoccupied = @"Yes";
 //vc1._IDofPrisonerString = testObject.objectId;
vc1._criminalID = fileDetails.objectId;
[self.navigationController pushViewController:vc1 animated:YES];


}


-(void)cancelButtonPressed:(id)sender {
    [self.m_PickerView removeFromSuperview];
}


- (void)saveButtonPressed:(id)sender {
    NSDate *myDate = self.m_DatePicker.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd-MMM-YYYY"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    
    [self.m_DOBButton setTitle:prettyVersion forState:UIControlStateNormal];

    [self.m_PickerView removeFromSuperview];
  
}




- (IBAction)saveDetailsButtonPressed:(id)sender {
    
    // Create PFObject with recipe information
    
    if ([self.m_textfieldfirstname.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"First Name Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else  if ([self.m_textfieldlastname.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Last Name Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else    if ([self.m_textfieldphonenumber.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Phone Number Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
    else      if ([self.m_textfieldaddress.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Address Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else       if ([self.m_textfieldstreet.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Street Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else                if ([self.m_textfieldcity.text length] < 1) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"City Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }
    else if ([[self.m_DOBButton titleForState:UIControlStateNormal] isEqualToString:@"D.O.B"]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"DOB Error" message:@"field cannot be empty" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
        [self checkEntry];

        NSLog(@"call send");
    }

}
            

- (void)checkEntry {
    
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];

    if ([self.m_textfieldfirstname.text length] > 0 && [self.m_textfieldlastname.text length]>0 && [self.m_textfieldphonenumber.text length] > 0) {
    
    
    PFQuery *query = [PFQuery queryWithClassName:@"prisoner_details"];
    [query whereKey:@"phone_number" equalTo:[numberFormatter numberFromString:_m_textfieldphonenumber.text]];
    [query whereKey:@"first_name" equalTo:_m_textfieldfirstname.text];
    [query whereKey:@"last_name" equalTo:_m_textfieldlastname.text];

    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *err) {
        if (!err) {
            
            if ([array count] > 0) {
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Error, criminal already exist!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                [alert show];

            }
            else {
                //Save
                PFObject *testObject = [PFObject objectWithClassName:@"prisoner_details"];
                ;
                testObject[@"phone_number"] = [numberFormatter numberFromString:_m_textfieldphonenumber.text] ;
                testObject[@"first_name"] = _m_textfieldfirstname.text;
                testObject[@"last_name"] = _m_textfieldlastname.text;
                testObject[@"address"] =  _m_textfieldaddress.text;
                testObject[@"city"] = _m_textfieldcity.text;
                testObject[@"street"] = _m_textfieldstreet.text;
                testObject [@"dob"] = [_m_DOBButton titleForState:UIControlStateNormal];
                testObject[@"authenticated_user"] = [[NSUserDefaults standardUserDefaults] objectForKey:@"LoggedinUser"];
                
                if ([_m_ProfileBtn backgroundImageForState:UIControlStateNormal]) {
                    
                    // Recipe image
                    NSData *imageData = UIImageJPEGRepresentation([_m_ProfileBtn backgroundImageForState:UIControlStateNormal], 0.8);
                    NSString *filename = [NSString stringWithFormat:@"123.png"];
                    PFFile *imageFile = [PFFile fileWithName:filename data:imageData];
                    [testObject setObject:imageFile forKey:@"photo"];
                    
                }

                
                [testObject saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error) {
                    
                    if (succeeded){
                        NSLog(@"Object Uploaded!");
                        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Saved Successfully!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
                        [alert show];
                        
                      //  testObject[@"prisoner_id"] = [[NSUserDefaults standardUserDefaults] objectForKey:@"testObject.objectId"];
                        
   

                          NSLog(@"value received is %@",                testObject.objectId);
                        CriminalRecordViewController  *vc1 = [[CriminalRecordViewController alloc] initWithNibName:nil bundle:nil];
                        vc1._IDofPrisonerString = testObject.objectId;
                        vc1._criminalID = testObject.objectId;
                        vc1.areallfieldsoccupied = @"No";
                        [self.navigationController pushViewController:vc1 animated:YES];

                    }
                    else{
                        NSString *errorString = [[error userInfo] objectForKey:@"error"];
                        NSLog(@"Error: %@", errorString);
                    }
                }];
}
        } else {
            
        }
    }];
    } else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Details Missing! Please check again!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];

    }
}









- (IBAction)dobPressed:(id)sender {
    [self.m_PickerView setFrame:CGRectMake(0, 200, self.m_PickerView.frame.size.width, self.m_PickerView.frame.size.height)];
    [self.view addSubview:self.m_PickerView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Text field Deletgates

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder]; //to resign keyboard
    return YES;
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end
